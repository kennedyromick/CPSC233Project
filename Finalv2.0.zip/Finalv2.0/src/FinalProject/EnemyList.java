package FinalProject;
import java.util.ArrayList;

import javafx.scene.paint.Color;

public class EnemyList extends ArrayList<Enemy> {
	
	public EnemyList()
	{
		makeEnemies();
	}
	public void makeEnemies()
	{	
		Enemy e1 = new Enemy(1300, 730, 30, 30, 50, 50, 600, 810, 0, 3);
		Enemy e2 = new Enemy(3000, 460, 50, 30, 300, 300, 450, 547, 0, 2);
		Enemy e3 = new Enemy(6000, 547, 50, 30, 590, 680, 460, 460, 2, 0);
		Enemy e4 = new Enemy(1200, 460, 50, 50, 500, 500, 450, 547, 0, 2);
		Enemy e5 = new Enemy(2500, 660, 30, 30, 600, 600, 650, 800, 0, 2);
		Enemy e6 = new Enemy(4000, 460, 50, 30, 300, 300, 450, 547, 0, 2);
		Enemy e7 = new Enemy(3000, 460, 50, 30, 300, 300, 450, 547, 0, 2);
		Enemy e8 = new Enemy(3300, 460, 50, 30, 300, 300, 450, 547, 0, 2);
		
		add(e1);
		add(e2);
		add(e3);
		add(e4);
		add(e5);
		add(e6);
		add(e7);
		add(e8);
	}


}
